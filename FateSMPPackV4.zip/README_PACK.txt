FateSMP Resource Pack (optional)
================================
Every fate tome is a CLOCK carrying a crystal in its own color with its motif
baked in at 32x32: godlike = crowned gold crystal, tidal = wave crystal,
inferno = flame crystal, thunderclap = haloed divine bolt, ...
Covers all 31 fate tomes (1001-1031), the Fate Reroller (999) and the
Mythic Reroller (997). The plugin works identically WITHOUT this pack.

NOTE: all 31 tomes share the clock item, so without the pack they all look
like clocks and only the name tells them apart. With the pack, plain clocks
animate exactly like vanilla ??? only tomes use the crystal textures.

Install (singleplayer / test):
  1. Drop FateSMP-ResourcePack.zip into your client's resourcepacks folder
     (or extract it so pack.mcmeta sits directly inside
     resourcepacks/FateSMP-ResourcePack/).
  2. Enable it under Options > Resource Packs. If Minecraft is already open,
     press F3+T to reload, or re-select the pack.
  3. Hold a fate tome: it should show the crystal art. A plain clock shows the
     normal clock face.
  4. Still vanilla? Check: the pack is enabled AND above any other pack that
     touches the clock, and the tome is a NEW one (/fate giveall) ??? very old
     tomes from before v2.1 use different model data.

Install (server-wide):
  Host the zip somewhere with a direct download URL and set in server.properties:
      resource-pack=<url>
  (require-resource-pack=false recommended so no-pack players can still join.)

Remove any time: nothing in the plugin depends on it.
